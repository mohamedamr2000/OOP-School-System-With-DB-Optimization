<?php
require_once('./templates/header.php');
require_once('Model/reg_model.php');
$id = $_GET['U_ID'];
$result = Registration::get_registration($id);
/*$result = Registration::get_reg_details($id);*/

?>
<html>
<head>
    <title>Transcript</title>
</head>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark"> Transcript </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 10%"> Student ID </td>
                                <td style="width: 20%"> Academic_Year </td>
                                <td style="width: 20%"> Registeration Date</td>
                                <td style="width: 20%"> Course Name</td>
                                <td style="width: 20%"> Final Grade</td>
                            </tr>
                            <tr>
                                <?php 
                                while($data= mysqli_fetch_assoc($result))
                                {
                                ?>
                                <?php $res2 = $data['Id']; 
                                $result2 = Registration::get_reg_details($res2); 
                                $data2 = mysqli_fetch_assoc($result2);
                                $res3 = $data2['Course_Id'];
                                $result3 = Registration::get_course($res3);
                                $data3 = mysqli_fetch_assoc($result3);
                                ?>
                                    <td><?php echo $data['Student_Id'] ?></td>
                                    <td><?php echo $data['Academic_Year'] ?></td>
                                    <td><?php echo $data['Date'] ?></td>
                                    <td><?php echo $data3['Course_Name'] ?></td>
                                    <td><?php echo $data2['Final_Grade'] ?></td>
                            </tr>
                            <?php
                                }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>