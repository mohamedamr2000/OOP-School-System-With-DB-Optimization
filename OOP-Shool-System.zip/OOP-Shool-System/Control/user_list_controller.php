<?php
require_once('./user_list_view.php');
require_once('./Model/user_model.php');
function sorting()
{
    if(isset($_POST['btn_sort1']))
    {
        $result=sortById::sort();
        return $result;
    }
    else if (isset($_POST['btn_sort2']))
    {
        $result=sortByName::sort();
        return $result;
    }
}
?>