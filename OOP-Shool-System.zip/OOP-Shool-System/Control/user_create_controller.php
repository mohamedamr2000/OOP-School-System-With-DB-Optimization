<?php
require_once('./Model/user_model.php');
require_once('./user_create_view.php');
if(isset($_POST['btn_save']))
{
    $obj = new User();
    $obj->firstName = $_POST['First']; 
    $obj->lastName = $_POST['Last'];
    $obj->password = $_POST['Password'];
    $obj->gender = $_POST['Gender'];
    $obj->email = $_POST['Email'];
    $obj->address = $_POST['Address'];
    $obj->userTypeId = $_POST['Role'];
    User::insert_user($obj);
}
?>