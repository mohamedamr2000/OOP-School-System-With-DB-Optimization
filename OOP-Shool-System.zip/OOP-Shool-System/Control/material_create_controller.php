<?php
require_once('./Model/material_model.php');
require_once('./material_create_view.php');
$id = $_GET['U_ID'];
$msg = "";
if (isset($_POST['upload'])) 
{
    $obj = new Material();
    $obj->image = $_FILES['image']['name'];
    $obj->image_text = $_POST['image_text'];
    $obj->course_id = $id;
    $target = "images/".basename($obj->image);
    Material::insert_material($obj);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target))
    {
        $msg = "Image uploaded successfully";
        //header("location: .\course_view.php");
    }
    else
    {
        $msg = "Failed to upload image";
    }
}
?>