<?php
require_once('./Model/reg_model.php');
require_once('./Model/payment_model.php');
require_once('./registration_create_view.php');
if(isset($_POST['btn_register']))
{
    $obj = new Registration();
    $obj->student_id = $_POST['student_id'];
    $obj->course_id = $_POST['course_id'];
    $obj->academic_year = $_POST['academic_year'];
    $obj->date = date("Y-m-d");
    $result = Payment::get_payment_amount($obj->student_id);
    while($data= mysqli_fetch_assoc($result))
    {
        $bool = $data ['Paid'];
    }
    if($bool == 1)
    {
        Registration::insert_registration($obj);
        echo "Sutdent has been registered into the course.";
    }
    else
    {
        echo "Registration failed: Awaiting payment from student.";
    }
}
?>