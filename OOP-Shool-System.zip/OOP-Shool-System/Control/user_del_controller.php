<?php
require_once("../Model/user_model.php");
$ID = $_GET['U_ID'];
User::delete_user($ID);
header("location: ../user_list_view.php");
?>