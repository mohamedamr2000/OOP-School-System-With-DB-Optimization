<?php
require_once('./Model/observer.php');
require_once('./set_grade_view.php');
if(isset($_POST['btn_set']))
{
    $conSubObj = new Concrete_Subject();
    $ObsObj1 = new Concrete_Observer_A($conSubObj);
    $ObsObj2 = new Concrete_Observer_B($conSubObj);
    $conSubObj->SetState(1);
}
?>