<?php
require_once('./Model/payment_model.php');
require_once('./payment_options_view2.php');
$r2 = $_SESSION['res2'];
if(isset($_POST['btn_pay']))
{
    for ($i=0; $i < Count($r2); $i++)
    {
        $obj = new Payment();
        $obj->payment_option_id = $r2[$i];
        $obj->value = $_POST [$i];
        $obj->student_id = $_POST['student_id'];
        Payment::insert_payment($obj);
       
    }
    echo "Payment submitted.";
}
?>