<?php
require_once('./Model/course_model.php');
require_once('./course_create_view.php');

if(isset($_POST['btn_add_course']))
{
    $obj = new Course();
    $obj->course_name = $_POST['course_name'];
    $obj->course_code = $_POST['course_code'];
    $obj->course_teacher = $_POST['course_teacher'];
    Course::insert_course($obj);
  
}
?>