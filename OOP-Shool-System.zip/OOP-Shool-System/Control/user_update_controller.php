<?php
require_once('./user_view.php');
require_once('./Model/user_model.php');
if(isset($_POST['btn_update']))
{
    $obje = new User();
    $obje->id = $_POST['ID']; 
    $obje->firstName = $_POST['First']; 
    $obje->lastName = $_POST['Last'];
    $obje->password = $_POST['Password'];
    $obje->gender = $_POST['Gender'];
    $obje->email = $_POST['Email'];
    $obje->address = $_POST['Address'];
    $obje->userTypeId = $_POST['Role'];
    User::update_user($obje);
}
?>