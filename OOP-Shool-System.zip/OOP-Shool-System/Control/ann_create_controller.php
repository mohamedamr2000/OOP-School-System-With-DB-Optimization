<?php
require_once('./Model/ann_model.php');
require_once('./ann_create_view.php');
require_once('./Model/observer.php');

if(isset($_POST['btn_publish']))
{
    $obj = new Ann();
    $obj->title = $_POST['title'];
    $obj->subject = $_POST['subject'];
    $obj->date = date("Y-m-d");
    Ann::insert_ann($obj);
  
}
?>