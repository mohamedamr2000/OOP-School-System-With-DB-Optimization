<html>
    <body>
        <form action="user_login_controller.php">
            <input type="text" name="id" value="" placeholder="ID"><br>
            <input type="password" name="password" value="" placeholder="Password"><br>
            <input type="submit" value="Submit">
        </form>
    </body>
</html>