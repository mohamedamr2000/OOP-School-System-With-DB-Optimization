<?php
require_once('./templates/header.php');
$id = $_GET['U_ID'];
$_SESSION['user_id'] = $id;
?>
<html>
<head>
    <title>Main</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark"> Menu </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                            <td style="width: 10%"><a href="user_list_view.php" class="btn btn-success">View All Users</a></td>
                            <td style="width: 10%"><a href="user_create_view.php" class="btn btn-success">Add New User</a></td>
                            <td style="width: 10%"><a href="course_create_view.php" class="btn btn-success">Add Course</a></td>
                            <td style="width: 10%"><a href="course_list_view.php?U_ID=<?php echo $id ?>" class="btn btn-success">My Courses</a></td>
                            <td style="width: 10%"><a href="set_grade_view.php" class="btn btn-success">Update Grade</a></td>
                        </tr>
                        <tr>
                            <td style="width: 10%"><a href="payment_method_view.php" class="btn btn-success">Pay Tution</a></td>
                            <td style="width: 10%"><a href="ann_create_view.php" class="btn btn-success">Make Announcement</a></td>
                            <td style="width: 10%"><a href="registration_create_view.php" class="btn btn-success">Register Student</a></td>
                            <td style="width: 10%"><a href="calender.php" class="btn btn-success">Shceduel</a></td>
                        </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</body>
</html>