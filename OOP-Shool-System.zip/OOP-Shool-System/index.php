<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel ="stylesheet" type="text/css" href="templates/style2.css">
    <link rel="stylesheet" href="templates/bootstrap.css">
</head>
<body>
    <div class="banner-area">
        <div class="content-area">
           <div class="content">
              <h1>BGLS</h1>
              
              <p>Baby Garden Language School</p>
              
              <a href="login.php" class="btn btn-danger">Sign In</a>
           </div>
        </div>
    </div>
</body>
</html>