<?php
require_once('./templates/header.php');
require_once('Model/course_model.php');
$id = $_GET['U_ID'];
$user_type = $_SESSION['user_type'];
?>
<html>
<head>
    <title>My courses</title>
</head>
<body class="white">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">Course Material</h2>
                    </div>
                    <div class="card-body">
                        <?php require_once('material_view.php'); ?>
                        <?php if ($user_type == 2){ ?>
                        <a href="material_create_view.php?U_ID=<?php echo $id?>" class="btn btn-success">Add Material</a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
