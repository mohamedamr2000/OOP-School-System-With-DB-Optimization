<?php
require_once('./templates/header.php');
require_once('Model/payment_model.php');
?>
<html>
<head>
    <title>Select Payment Method</title>
</head>
<body class="white">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">Select Payment Method </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 10%"> No. </td>
                                <td style="width: 10%"> Name </td>
                            </tr>
                            <tr>
                                <?php 
                                $result = Payment::view_payment_method();
                                while($data= mysqli_fetch_assoc($result))
                                {
                                ?>
                                    <td><?php echo $data['Id'] ?></td>
                                    <td><?php echo $data['Name'] ?></td>
                                    <td><a href="payment_options_view2.php?U_ID=<?php echo $data['Id'] ?>" class="btn btn-success">Select</a></td>
                            </tr>
                            <?php
                                }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>