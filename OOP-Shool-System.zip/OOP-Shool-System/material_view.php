<?php
require_once('./Model/material_model.php');
$id = $_GET['U_ID'];
$result = Material::view_material($id);
?>
<html>
<head>
<title>Image Upload</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
<link rel ="stylesheet" type="text/css" href="templates/assig_design.css">
</head>
<body>

  <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
      	echo "<img src='images/".$row['Image']."' >";
      	echo "<p>".$row['Text']."</p>";
      echo "</div>";
    }
  ?>
</body>
</html>