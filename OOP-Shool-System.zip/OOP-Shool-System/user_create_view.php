<?php
require_once('./Control/user_create_controller.php');
require_once('./templates/header.php');
?>
<html>
<head>
    <title>Store Record</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2> Register New User </h2>
                    </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="text" name="First" placeholder="First name" class="form-control mb-2" required>
                                <input type="text" name="Last" placeholder="Last name" class="form-control mb-2" required>
                                <input type="text" name="Password" placeholder="Password" class="form-control mb-2" required>
                                <input type="Email" name="Email" placeholder="Email" class="form-control mb-2" required>
                                <input type="text" name="Gender" placeholder="Gender" class="form-control mb-2" required>
                                <input type="text" name="Address" placeholder="Address" class="form-control mb-2" required>
                                <input type="text" name="Role" placeholder="Role" class="form-control mb-2" required>
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-success" name="btn_save"> Add user </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>