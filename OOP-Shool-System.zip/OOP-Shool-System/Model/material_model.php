<?php
require_once('dbconfig.php');
class Material
{
    public $id;
    public $image;
    public $image_text;
    public $course_id;

    public static function insert_material($obj)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into material (Image,Text,Course_Id) values('$obj->image','$obj->image_text','$obj->course_id')";
        mysqli_query($connection,$query);
    }

    public function view_material($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from material where Course_Id='$id'";
        $result = mysqli_query($connection,$query);
        return $result;
    }
}

?>