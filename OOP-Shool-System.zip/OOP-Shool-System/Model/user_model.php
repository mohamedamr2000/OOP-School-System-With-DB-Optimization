<?php
require_once('dbconfig.php');
class User
{
    public $id;
    public $firstName;
    public $lastName;
    public $password;
    public $gender;
    public $email;
    public $address;
    public $userTypeId;

    public static function insert_user($objUser)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into users (firstName,lastName,gender,email,address,userTypeId,password) values('$objUser->firstName',
        '$objUser->lastName','$objUser->gender','$objUser->email','$objUser->address','$objUser->userTypeId','$objUser->password')";
        mysqli_query($connection,$query);
    }

    public function view_list_user()
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from users ";
        $result = mysqli_query($connection,$query);
        return $result;
    }

    public function get_user($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query ="select * from users where id='$id'";
        $result = mysqli_query($connection,$query);
        return $result;
    }

    public static function update_user($objUser)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection(); 
        $query = "UPDATE users SET firstName='$objUser->firstName', lastName='$objUser->lastName', gender='$objUser->gender', 
        email='$objUser->email', address='$objUser->address', userTypeId='$objUser->userTypeId', password='$objUser->password' 
        WHERE id='$objUser->id'";
        mysqli_query($connection,$query);
    }

    public function delete_user($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "delete from users where id='$id'";
        $result = mysqli_query($connection,$query);
    }

    public static function login($id, $pswrd)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from users WHERE id='$id' and password='$pswrd'";
        $result = mysqli_query($connection,$query);
        $data = mysqli_fetch_assoc($result);
        return $data['userTypeId'];
    }

    public function get_usertype($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query ="select * from users where id='$id'";
        $result = mysqli_query($connection,$query);
        while($data= mysqli_fetch_assoc($result))
        {
            $res = $data['userTypeId'];
        }
        return $res;
    }
}

interface iSort
{
    public function sort();
}
 

class sortByName implements iSort{
    public function sort()
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from users order by firstName";
        $result = mysqli_query($connection,$query);
        return $result;
    }
}

class sortById implements iSort{
    public function sort()
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from users order by Id";
        $result = mysqli_query($connection,$query);
        return $result;
    }
}
?>