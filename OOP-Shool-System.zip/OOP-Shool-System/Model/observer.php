<?php
require_once('dbconfig.php');
class Subject
{
    private $observers = array();

    public function Attach(Observer $obj)
    {
        array_push($this->observers, $obj);
    }
    public function Notify()
    {
        for ($i = 0; $i < Count($this->observers); $i++)
        {
            $this->observers[$i]->Update();
        }
    }
} 

class Concrete_Subject extends Subject
{
    private $state;
    public function SetState($value)
    {
        $this->state = $value;
        $this->Notify();
    }

    public function GetState()
    {
        return $this->state;
    }
}

abstract class Observer
{
    public abstract function Update();
}

class Concrete_Observer_A extends Observer
{
    private $state;
    private $consub;

    public function __construct(Concrete_Subject $obj)
    {
        $this->conSub = $obj;
        $this->conSub->Attach($this);
    }

    public function Update()
    {
        $this->state = $this->conSub->GetState();
        if ($this->state == 1)
        {
        echo "Observer1: Email notification sent.        ";
        }

    }
}

class Concrete_Observer_B extends Observer
{
    private $state;
    private $consub;

    public function __construct(Concrete_Subject $obj)
    {
        $this->conSub = $obj;
        $this->conSub->Attach($this);
    }

    public function Update()
    {
        $this->state = $this->conSub->GetState();
        if ($this->state == 1)
        {
            echo "Observer2: Grade updated in database.";

            $db=DbConnection::getInstance();
            $connection = $db->getConnection(); 
            $query = "UPDATE registration_details SET notify='1' WHERE Registration_Id='17'";
            mysqli_query($connection,$query);
            $query2 = "UPDATE registration_details SET Final_Grade='80' WHERE Registration_Id='17'";
            mysqli_query($connection,$query2);
            
            
        }
    }
}


?>