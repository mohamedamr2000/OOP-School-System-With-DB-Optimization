<?php
require_once('dbconfig.php');
class Payment
{
    public $student_id;
    public $value;
    public $payment_option_id;

    public static function view_payment_method()
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from payment_method";
        $result = mysqli_query($connection,$query);
        return $result;
    }

    public function get_payment_options($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query ="select * from payment_options where Payment_Id='$id'";
        $result = mysqli_query($connection,$query);
        $options = array();
        while($data= mysqli_fetch_assoc($result))
        {
            $var = $data ['Id'];
            $query2 ="select * from options where Id='$var'";
            $result2 = mysqli_query($connection,$query2);
            while($data= mysqli_fetch_assoc($result2))
            {
                array_push($options, $data['Name']);

            }
        }
        return $options;
    } 

    public function get_payment_options_id($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query ="select * from payment_options where Payment_Id='$id'";
        $result = mysqli_query($connection,$query);
        $arr = array();
        while($data= mysqli_fetch_assoc($result))
        {
            array_push($arr, $data['Id']);
        }
        return $arr;
    }

    public function insert_payment($obj)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into payment_option_value (Payment_Option_Id,Student_Id,Value) values('$obj->payment_option_id',
        '$obj->student_id','$obj->value')"; 
        mysqli_query($connection,$query);
        $query2 = "UPDATE payment_amount SET Paid='1'WHERE Student_Id='$obj->student_id'";
        mysqli_query($connection,$query2);
    }

    public function get_payment_amount($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from payment_amount where Student_Id='$id'";
        $result = mysqli_query($connection,$query);
        return $result;
    }
}