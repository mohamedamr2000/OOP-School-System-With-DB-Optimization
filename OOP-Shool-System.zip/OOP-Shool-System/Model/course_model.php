<?php
require_once('dbconfig.php');
class Course
{
    public $id;
    public $course_name;
    public $course_code;
    public $course_teacher;

    public static function insert_course($obj)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into course (Course_Name,Course_Code) values('$obj->course_name','$obj->course_code')";
        mysqli_query($connection,$query);
        $query2 = "SELECT * FROM course WHERE Id = (SELECT MAX(ID) FROM course)";
        $result = mysqli_query($connection,$query2);
        while($data= mysqli_fetch_assoc($result))
        {
            $var = $data ['Id'];
        }
        $query3 = "insert into course_teachers (Course_Id, Teacher_Id) values('$var','$obj->course_teacher')";
        mysqli_query($connection,$query3);
    }

    public function view_list_courses($id,$user_type)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $courses = array();
        if ($user_type == 1)
        {
            $query = "select * from registration where Student_Id='$id'";
            $result = mysqli_query($connection,$query);
            while($data= mysqli_fetch_assoc($result))
            {
                $var = $data['Id'];
                $query2 = "select * from registration_details where Registration_Id='$var'";
                $result2 = mysqli_query($connection,$query2);
                while($data3= mysqli_fetch_assoc($result2))
                {
                    $var3 = $data3['Course_Id'];
                    $query3 = "select * from course where Id='$var3'";
                    $result3 = mysqli_query($connection,$query3);
                    while($data4= mysqli_fetch_assoc($result3))
                    {
                        array_push($courses, $data4['Course_Name']);
                        array_push($courses, $data4['Id']);
                    }
                }
            }
        }
        else if ($user_type == 2)
        {
            $query = "select * from course_teachers where Teacher_Id='$id'";
            $result = mysqli_query($connection,$query);
            while($data= mysqli_fetch_assoc($result))
            {
                $var = $data['Course_Id'];
                $query2 = "select * from course where id='$var'";
                $result2 = mysqli_query($connection,$query2);
                while($data= mysqli_fetch_assoc($result2))
                {
                    array_push($courses, $data['Course_Name']);
                    array_push($courses, $data['Id']);
                }
            }
        }
        return $courses;
    }
}
?>