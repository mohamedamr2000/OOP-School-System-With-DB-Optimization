<?php
require_once('dbconfig.php');
class Ann
{
    public $tile;
    public $subject;
    public $date;
    public $notify = 0;

    public static function insert_ann($annObj)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into ann (title,subject,date) values('$annObj->title','$annObj->subject','$annObj->date')";
        mysqli_query($connection,$query);
    }

    public function view_list_ann()
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from ann ";
        $result = mysqli_query($connection,$query);
        return $result;
    }
}
?>