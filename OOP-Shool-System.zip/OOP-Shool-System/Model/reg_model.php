<?php
require_once('dbconfig.php');
class Registration
{
    public $student_id;
    public $academic_year;
    public $course_id;
    public $date;

    public static function insert_registration($obj)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "insert into registration (Student_Id,Academic_Year,Date) values('$obj->student_id','$obj->academic_year','$obj->date')";
        mysqli_query($connection,$query);
        $query2 = "SELECT * FROM registration WHERE Id = (SELECT MAX(ID) FROM registration)";
        $result = mysqli_query($connection,$query2);
        while($data= mysqli_fetch_assoc($result))
        {
            $var = $data ['Id'];
        }
        $query3 = "insert into registration_details (Registration_Id,Course_Id) values('$var','$obj->course_id')";
        mysqli_query($connection,$query3);
    }

    public static function get_registration($id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from registration where Student_Id='$id'";
        $result = mysqli_query($connection,$query);
        return $result;
    }

    public static function get_reg_details($reg_id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from registration_details where Registration_Id='$reg_id'";
        $result2 = mysqli_query($connection,$query);
        return $result2;
    }

    public static function get_course($course_id)
    {
        $db=DbConnection::getInstance();
        $connection = $db->getConnection();
        $query = "select * from course where Id='$course_id'";
        $result3 = mysqli_query($connection,$query);
        return $result3;
    }


}
?>