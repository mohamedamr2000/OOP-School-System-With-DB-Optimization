<?php
require_once('./Control/registration_create_controller.php');
require_once('./templates/header.php');
?>
<html>
<head>
    <title>Student Registration</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2>Student Registration</h2>
                    </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="text" name="student_id" placeholder="Student ID" class="form-control mb-2" required>
                                <input type="text" name="course_id" placeholder="Course ID" class="form-control mb-2" required>
                                <input type="text" name="academic_year" placeholder="Academic Year" class="form-control mb-2" required>
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-success" name="btn_register"> Register Student </button>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>