<?php
require_once('./Control/material_create_controller.php');
$id = $_GET['U_ID'];
?>
<html>
<head>
<title>Image Upload</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
<link rel ="stylesheet" type="text/css" href="templates/assig_design.css">
</head>
<body>
<div id="content">
  <form method="POST" action="material_create_view.php?U_ID=<?php echo $id?>" enctype="multipart/form-data">
  	<div>
  	  <input type="file" name="image">
  	</div>
  	<div>
      <textarea id="text" cols="40" rows="4" name="image_text" placeholder="Write your text here.."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>
</div>
</body>
</html>