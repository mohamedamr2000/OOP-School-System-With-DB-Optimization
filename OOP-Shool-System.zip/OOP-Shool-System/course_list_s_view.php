<?php
require_once('./templates/header.php');
require_once('Model/course_model.php');
$id = $_GET['U_ID'];
$result = Course::view_list_courses($id);
?>
<html>
<head>
    <title>My courses</title>
</head>
<body class="white">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">My Courses</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 50%"> Course Name </td>
                            </tr>
                            <tr>
                                <?php 
                                for($i=0;$i<Count($result);$i+=2)
                                {
                                ?>
                                    <td><?php echo $result[$i] ?></td>
                                    <td><a href="course_view.php?U_ID=<?php echo $result[$i+1] ?>" class="btn btn-success">Select</a></td>
                            </tr>
                            <?php
                                }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>