<?php
require_once('Model/user_model.php');
session_start();
$user_id = $_SESSION['user_id'];
$user_type = User::get_usertype($user_id);
$_SESSION['user_type'] = $user_type;
?>

<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel ="stylesheet" type="text/css" href="templates/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="templates/bootstrap.css">
</head>
<body>
    <div class ="header">
        <div class="inner_header">
            <div class ="logo_container">
                <h1>School<span> e-learning</span></h1>
            </div>
            <ul class ="navigation">

            </ul>
        </div>
    </div>
</body>
</html>