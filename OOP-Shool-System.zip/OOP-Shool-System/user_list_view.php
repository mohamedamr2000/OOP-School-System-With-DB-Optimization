<?php 
require_once('./templates/header.php');
require_once('Control/user_list_controller.php');
?>
<html>
<head>
    <title>User List</title>
</head>
<body class="white">
<form method="POST">
<button class="btn btn-success"  name="btn_sort1"> Sort 1 </button>
<button class="btn btn-success"  name="btn_sort2"> Sort 2 </button>
</form>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark"> Users </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 10%"> id </td>
                                <td style="width: 10%"> First Name </td>
                                <td style="width: 20%"> Last name </td>
                                <td style="width: 20%"> Gender </td>
                                <td style="width: 20%"> Email </td>
                                <td style="width: 20%"> Adress </td>
                                <td style="width: 20%"> Role </td>
                                <td style="width: 20" colspan="2">Operations</td>
                            </tr>
                            <tr>
                                <?php 
                                $result = sorting();
                                while($data= mysqli_fetch_assoc($result))
                                {
                                ?>
                                    <td><?php echo $data['id'] ?></td>
                                    <td><?php echo $data['firstName'] ?></td>
                                    <td><?php echo $data['lastName'] ?></td>
                                    <td><?php echo $data['gender'] ?></td>
                                    <td><?php echo $data['email'] ?></td>
                                    <td><?php echo $data['address'] ?></td>
                                    <td><?php echo $data['userTypeId'] ?></td>
                                    <td><a href="user_view.php?U_ID=<?php echo $data['id'] ?>" class="btn btn-success">Edit</a></td>
                                    <td><a href="Control/user_del_controller.php?U_ID=<?php echo $data['id'] ?>" class="btn btn-danger">Del</a></td>
                                    <td><a href="transcript.php?U_ID=<?php echo $data['id'] ?>" class="btn btn-danger">Transcript</a></td>
                            </tr>
                            <?php
                                }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>