<?php
require_once('./Control/course_create_controller.php');
require_once('./templates/header.php');
$user_type = $_SESSION['user_type'];
?>
<html>
<head>
    <title>Course Menu</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2> Course Menu </h2>
                    </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="text" name="course_name" placeholder="Course Name" class="form-control mb-2" required>
                               
                                <input type="text" name="course_code" placeholder="Course Code" class="form-control mb-2" required>

                                <input type="text" name="course_teacher" placeholder="Course Teacher" class="form-control mb-2" required>
                        </div>
                    <div class="card-footer">
                            <button class="btn btn-success" name="btn_add_course"> Add Course </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>