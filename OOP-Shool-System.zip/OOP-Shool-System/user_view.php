<?php
require_once('./templates/header.php');
require_once('Model/user_model.php');
require_once('Control/user_update_controller.php');
$id = $_GET['U_ID'];
$result = User::get_user($id);
$data = mysqli_fetch_assoc($result);
?>
<html>
<head>
    <title>User Record</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2> Update User Info </h2>
                    </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="ID" value="<?php echo $data['id']?>">
                                <input type="text" name="First" placeholder="First name" class="form-control mb-2" required value="<?php echo $data['firstName']?>">
                                <input type="text" name="Last" placeholder="Last name" class="form-control mb-2" required value="<?php echo $data['lastName']?>">
                                <input type="text" name="Gender" placeholder="Gender" class="form-control mb-2" required value="<?php echo $data['gender']?>">
                                <input type="Email" name="Email" placeholder="Email" class="form-control mb-2" required value="<?php echo $data['email']?>">
                                <input type="text" name="Address" placeholder="Address" class="form-control mb-2" required value="<?php echo $data['address']?>">
                                <input type="text" name="Role" placeholder="Role" class="form-control mb-2" required value="<?php echo $data['userTypeId']?>">
                                <input type="text" name="Password" placeholder="Password" class="form-control mb-2" required value="<?php echo $data['password']?>">
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-success" name="btn_update">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>