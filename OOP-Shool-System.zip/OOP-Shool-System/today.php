<?php require_once('./templates/header.php'); ?>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Subject</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<?php
require_once('./Model/ann_model.php');
$result = ann::view_list_ann();
while($data= mysqli_fetch_assoc($result))
{
?>
<?php
    if (date("Y-m-d") == $data['date'])
    {
?>
        <td><?php echo $data['id'];?></td>
        <td><?php echo $data['title'];?></td>
        <td><?php echo $data['subject'];?></td>
        <td><?php echo $data['date'];?></td>
 <?php
    }
    ?>
<?php
}
?>
  </tbody>
</table>




