<?php
require_once("Model/user_model.php");
$id = $_GET['id'];
$pswrd = $_GET['password'];
$userType = 0;
$userType = User::login($id, $pswrd);



if($userType==0)
{
    echo("Wrong id or password");
}
else
{
?>
<a href="home.php?U_ID=<?php echo $id ?>" class="btn btn-danger">Main Menu</a>
    <?php
    //header("location: ..\home.php");
}
?>

