<?php
require_once('./templates/header.php');
require_once('Model/payment_model.php');
require_once('Control/payment_controller.php');

$id = $_GET['U_ID'];
$result = Payment::get_payment_options($id);
$result2 = Payment::get_payment_options_id($id);

$_SESSION['res2'] = $result2;
?>
<html>
<head>
    <title>Check in</title>
</head>
<body class="white">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">Check in</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                        <tr>
                                <td style="width: 5%"> </td>
                                <td style="width: 20%"> </td>
                            </tr>
                            <form method = "POST">
                            <input type="text" name="student_id" placeholder="Student Id" class="form-control mb-2" required>

                            <button class="btn btn-success" name="btn_pay"> Confirm Payment </button>
                            
                            <tr>
                            
                                <?php 
                                
                                $arr = array();
                                for ($i=0; $i < Count($result); $i++)
                                {
                                ?>
                                    <td><?php echo $result[$i]; array_push($arr, $result[$i]); ?></td>
                                    <td><input type="text" name="<?php echo $result[$i];?> " placeholder="1" class="form-control mb-2" required></td>
                            <?php
                                }
                                $_SESSION['res1'] = $arr;
                                ?>
                                
                               
                                </tr>
                                </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>